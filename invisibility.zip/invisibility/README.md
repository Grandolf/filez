
Invisibility Potion by TenPlus1

This mod lets you craft an invisibility potion using one of each sapling (tree, jungle, pine, acacia, aspen, bush, acacia bush), a red mushroom and glass bottle.

Use potion to hide yourself AND nametag (0.4.15+ only) for 3 minutes.

Server admin can use the '/vanish <name>' command to hide/unhide players or themselves by leaving it blank.

Forum Page: https://forum.minetest.net/viewtopic.php?f=9&t=14846

Changelog:

 - 0.1 - Initial Upload
 - 0.2 - Added error checking and a 10 second warning before becoming visible
 - 0.3 - Potions can now be stacked
 - 0.4 - Potion recipe changed now that Nyan Cat no longer in default game
 - 0.5 - Use newer functions, Minetest 0.4.16 and anove needed to run
