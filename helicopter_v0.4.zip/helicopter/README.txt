Minetest 0.4.7+ mod: Simple helicopter
=======================
by Pavel_S

License of source code:
-----------------------
GPL_v2

License of media (textures and sounds):
---------------------------------------

helicopter_motor.ogg by  Robinhood76 | License: Attribution Noncommercial

