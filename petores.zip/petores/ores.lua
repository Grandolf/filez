petores = {}

-- ===================================================================

local COPPERSTONE  = true
local DIAMONDSTONE = true
local GOLDSTONE    = true
local IRONSTONE    = true
local MITHRILSTONE = true
local SILVERSTONE  = true
local TINSTONE     = true

local lottores = false
if minetest.get_modpath ("lottores") then
      lottores = true
end

local MODNAME = minetest.get_current_modname()
local MODPATH = minetest.get_modpath (MODNAME)
local SNDPATH = MODPATH .. "/sounds"

function petores:ogg_exists (name)
    local f = io.open (SNDPATH .. "/" .. name .. ".ogg", "r")
    if f ~= nil then io.close (f) return true else return false end
end

-- ===================================================================

function petores:mobore (params)

local name        = params.name
local fullname    = "petores:" .. name
local img         = name .. ".png"
local clicksound  = params.clicksound

mobs:register_mob (fullname, {
    armor                = params.armor      ,
    type                 = "animal"          ,
    hp_min               = params.hp_min     ,
    hp_max               = params.hp_max     ,
    drawtype             = "front"           ,
    follow               = params.follow     ,
    jump                 = true              ,
    lava_damage          = 2                 ,
    light_damage         = 0                 ,
    makes_footstep_sound = false             ,
    passive              = true              ,
    view_range           = params.view_range ,
    visual               = "cube"            ,
    walk_velocity        = 1                 ,
    water_damage         = 1                 ,

    collisionbox = { -0.25, -0.33, -0.25, 0.25, 0.33, 0.25 } ,
    textures     = { img, img, img, img, img, img          } ,
    visual_size  = { x=0.7, y=0.7                          } ,

    drops =
    {
        {
            name = params.dropnode,
            chance = 1,
            min = 1,
            max = params.dropmax
        } ,
    } ,

    on_rightclick = function(self, clicker)
        tool = clicker:get_wielded_item():get_name()
        if tool == "petores:cage" then
                clicker:get_inventory():remove_item("main", "petores:cage")
                clicker:get_inventory():add_item("main", fullname)
                self.object:remove()
        else
            if not mobs:feed_tame (self, clicker, 1, true) and
               petores:ogg_exists (clicksound) then
                minetest.sound_play (clicksound,
                {
                    pos=clicker:getpos(),
                    gain = 2.0, max_hear_distance = 100
                })
            end
        end
    end,
})

minetest.register_craftitem (fullname, {
    description     = params.description ,
    inventory_image = img                ,
    on_place = function(itemstack, placer, pointed_thing)
        if pointed_thing.above then
            minetest.env:add_entity(pointed_thing.above, fullname)
            if minetest.setting_getbool("creative_mode") then
                itemstack:take_item()
            else 
                itemstack:take_item()
                placer:get_inventory():add_item("main", "petores:cage")
            end
        end
        return itemstack
    end,
})
end

-- ===================================================================

petores:mobore ({
    armor       = 50                    ,
    clicksound  = "oresqueak"           ,
    description = "Copper Stone Ore"    ,
    dropmax     = 6                     ,
    dropnode    = "default:copper_lump" ,
    follow      = "wool:black"          ,
    hp_max      =  4                    ,
    hp_min      =  1                    ,
    name        = "copperstone"         ,
    view_range  = 10                    ,
})

if COPPERSTONE then
mobs:register_spawn ("petores:copperstone",
{
    "darkage:marble"            ,
    "default:cobble"            ,
    "default:mossycobble"       ,
    "default:stone"             ,
    "default:stonebrick"        ,
}, 20, 0, 12000, 12, 31000)
end

-- ===================================================================

petores:mobore ({
    armor       = 50                    ,
    clicksound  = "oresqueak"           ,
    description = "Iron Stone Ore"      ,
    dropmax     = 6                     ,
    dropnode    = "default:iron_lump"   ,
    follow      = "wool:black"          ,
    hp_max      =  4                    ,
    hp_min      =  1                    ,
    name        = "ironstone"           ,
    view_range  = 10                    ,
})

if IRONSTONE then
mobs:register_spawn ("petores:ironstone",
{
    "darkage:marble"            ,
    "default:cobble"            ,
    "default:mossycobble"       ,
    "default:stone"             ,
    "default:stonebrick"        ,
}, 20, 0, 12000, 12, 31000)
end

-- ===================================================================

petores:mobore ({
    armor       = 50                    ,
    clicksound  = "oresqueak"           ,
    description = "Diamond Ore"         ,
    dropmax     = 1                     ,
    dropnode    = "default:diamond"     ,
    follow      = "wool:black"          ,
    hp_max      =  4                    ,
    hp_min      =  1                    ,
    name        = "diamondstone"        ,
    view_range  = 10                    ,
})

if DIAMONDSTONE then
mobs:register_spawn ("petores:diamondstone",
{
    "darkage:marble"            ,
    "default:cobble"            ,
    "default:mossycobble"       ,
    "default:stone"             ,
    "default:stonebrick"        ,
}, 20, 0, 12000, 12, 31000)
end

-- ===================================================================

petores:mobore ({
    armor       = 50                    ,
    clicksound  = "oresqueak"           ,
    description = "Gold Ore"            ,
    dropmax     = 1                     ,
    dropnode    = "default:gold_lump"   ,
    follow      = "wool:black"          ,
    hp_max      =  4                    ,
    hp_min      =  1                    ,
    name        = "goldstone"           ,
    view_range  = 10                    ,
})

if GOLDSTONE then
mobs:register_spawn ("petores:goldstone",
{
    "darkage:marble"            ,
    "default:cobble"            ,
    "default:mossycobble"       ,
    "default:stone"             ,
    "default:stonebrick"        ,
}, 20, 0, 12000, 12, 31000)
end

-- ===================================================================

if lottores then
petores:mobore ({
    armor       = 50                      ,
    clicksound  = "oresqueak"             ,
    description = "Mithril Ore"           ,
    dropmax     =  1                      ,
    dropnode    = "lottores:mithril_lump" ,
    follow      = "wool:black"            ,
    hp_max      =  4                      ,
    hp_min      =  1                    ,
    name        = "mithrilstone"          ,
    view_range  = 10                      ,
})

if MITHRILSTONE then
mobs:register_spawn ("petores:mithrilstone",
{
    "darkage:marble"            ,
    "default:cobble"            ,
    "default:mossycobble"       ,
    "default:stone"             ,
    "default:stonebrick"        ,
}, 20, 0, 16000, 12, 31000)
end
end

-- ===================================================================

if lottores then
petores:mobore ({
    armor       = 50                      ,
    clicksound  = "oresqueak"             ,
    description = "Silver Ore"            ,
    dropmax     =  3                      ,
    dropnode    = "lottores:silver_lump"  ,
    follow      = "wool:black"            ,
    hp_max      =  4                      ,
    hp_min      =  1                    ,
    name        = "silverstone"           ,
    view_range  = 10                      ,
})

if SILVERSTONE then
mobs:register_spawn ("petores:silverstone",
{
    "darkage:marble"            ,
    "default:cobble"            ,
    "default:mossycobble"       ,
    "default:stone"             ,
    "default:stonebrick"        ,
}, 20, 0, 12000, 12, 31000)
end
end

-- ===================================================================

if lottores then
petores:mobore ({
    armor       = 50                      ,
    clicksound  = "oresqueak"             ,
    description = "Tin Ore"               ,
    dropmax     =  6                      ,
    dropnode    = "lottores:tin_lump"     ,
    follow      = "wool:black"            ,
    hp_max      =  4                      ,
    hp_min      =  1                      ,
    name        = "tinstone"              ,
    view_range  = 10                      ,
})

if TINSTONE then
mobs:register_spawn ("petores:tinstone",
{
    "darkage:marble"            ,
    "default:cobble"            ,
    "default:mossycobble"       ,
    "default:stone"             ,
    "default:stonebrick"        ,
}, 20, 0, 12000, 12, 31000)
end
end
