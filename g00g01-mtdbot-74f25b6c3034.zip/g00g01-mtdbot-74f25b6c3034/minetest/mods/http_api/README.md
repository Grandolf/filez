Http API Discord bot
============================

<googolgl@gmail.com>

============================
-- Add this mods to trusted_mods
-- Open : minetest.confg
-- Add : secure.http_mods = subscriber,publisher