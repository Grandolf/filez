package main

import (
    "fmt"
    "log"
    "encoding/json"
    "io/ioutil"
    "net/http"
    "flag"
    "strings"
    "regexp"

    "github.com/jcuga/golongpoll"
    "github.com/bwmarrin/discordgo"
    "github.com/vharitonsky/iniflags"
)

type json_data struct {
    Type    string      `json:"type"`
    Player  string      `json:"player"`
    Message string      `json:"message"`
    Command string      `json:"command"`
    Args    []string    `json:"args"`
}

var (
    BotID       string
    minetestReq     chan json_data
    minetestResp    chan json_data

    Token = flag.String("token", "", "Bot Token")
    ChanID = flag.String("channel", "", "Channel ID for bot messages")
    HostBind = flag.String("host", "127.0.0.1:8003", "Host binding <host:port>")
    Censore = flag.Bool("censore", false, "Enable or disable censore")
    CensWords = flag.String("censwords", "", "List of uncensored words")
    CensRunCommand = flag.String("censcmd", "", "Run command if exist uncensored words")
    CensMsgCommand = flag.String("censmsg", "", "Message for the user who wrote uncensored words ")
)

func main() {
    iniflags.Parse()

    minetestReq = make(chan json_data)
    minetestResp = make(chan json_data)

    manager, err := golongpoll.StartLongpoll(golongpoll.Options{
        LoggingEnabled:                 true,
        MaxLongpollTimeoutSeconds:      26,
        MaxEventBufferSize:             100,
        EventTimeToLiveSeconds:         20,
        DeleteEventAfterFirstRetrieval: false,
    })
    if err != nil {
        log.Fatalf("Failed to create manager: %q", err)
    }

    go discordBot()
    go minetestSub(manager)

// Serve our event subscription web handler
    http.HandleFunc("/sub", manager.SubscriptionHandler)
    http.HandleFunc("/pub", PubReq)

    fmt.Println("Starting the server on "+*HostBind+"...")
    http.ListenAndServe(*HostBind, nil)

// Shutdown:
    manager.Shutdown() // Stops the internal goroutine that provides subscription behavior
}

func discordBot() {
// Create a new Discord session using the provided bot token.
    dg, err := discordgo.New("Bot "+*Token)
    if err != nil {
        fmt.Println("error creating Discord session,", err)
        return
    }

// Get the account information.
    u, err := dg.User("@me")
    if err != nil {
        fmt.Println("error obtaining account details,", err)
    }

    BotID = u.ID
    go sendMessage(dg)

// Register messageCreate as a callback for the messageCreate events.
    dg.AddHandler(messageCreate)

// Open the websocket and begin listening.
    err = dg.Open()
    if err != nil {
        fmt.Println("error opening connection,", err)
        return
    }

    fmt.Println("Bot is now running.  Press CTRL-C to exit.")
// Simple way to keep program running until CTRL-C is pressed.
    <-make(chan struct{})
    return
}

func sendMessage(s *discordgo.Session) {
    for {
        msg := <- minetestReq
        // Check censore
        if *Censore == true {
            _, _ = s.ChannelMessageSend(*ChanID, "<"+msg.Player+"> "+CensorCheck(msg.Player, msg.Message, *CensWords))
        } else {
            _, _ = s.ChannelMessageSend(*ChanID, "<"+msg.Player+"> "+msg.Message)
        }
    }
}

func messageCreate(s *discordgo.Session, m *discordgo.MessageCreate) {
// Ignore all messages created by the bot itself
    if m.Author.ID == BotID {
        return
    }

    if m.ChannelID == *ChanID {
// Starting parse command from discord
        TypeMsg 	:= "chat"
        MessageText	:= m.Content
        PlayerName	:= m.Author.Username
        command 	:= ""
        arguments 	:= []string{}
        mtCommands	:= []string{
                                "ban",          //Ban players
                                "unban",        //UnBan players
                                "kick",         //Kick
                                "setpassword",  //Edit password
                                "grant",        //Gives the privilege to player
                                "revoke",       //Takes away a privilege from player
                                "privs",        //Show privs of player
                                "status",       //Status of the server
                                "msg",          //Private message
                            }

        for _, TypeCmd := range mtCommands {
            if strings.HasPrefix(MessageText, "!"+TypeCmd) == true {
                TypeMsg = "cmd"
                MessageText = strings.TrimSpace(strings.TrimPrefix(MessageText, "!"+TypeCmd))
                arguments = strings.Fields(MessageText)
                if MessageText != "" {
                    MessageText = strings.TrimSpace(strings.TrimPrefix(MessageText, arguments[0]))
                }
                command = TypeCmd
            }
        }

        actionEvent := json_data{
            Type:       TypeMsg,
            Message:    MessageText,
            Player:     PlayerName,
            Command:    command,
            Args:       arguments,
        }
        minetestResp <- actionEvent
    }
}

func PubReq(w http.ResponseWriter, req *http.Request) {
    body, readErr := ioutil.ReadAll(req.Body)
    if readErr != nil {
        panic(readErr)
        return
    }

    PubReq := json_data{}
    jsonErr := json.Unmarshal(body, &PubReq)
    if jsonErr != nil {
        panic(jsonErr)
        return
    }
    fmt.Println(PubReq)
    minetestReq <- PubReq
}

func minetestSub(lpManager *golongpoll.LongpollManager) {
    for {
        msg := <- minetestResp
        lpManager.Publish("minetest", msg)
    }
}

func CensorCheck(player string, str string, censored string) string {
    var newSlice []string
    // check for empty slice
    if len(censored) <= 0 {
        return str
    }

    // convert str & censored into a slices
    strSlice := strings.Fields(str)
    censWordsSlice := strings.Fields(censored)

    var re = regexp.MustCompile(`[[:punct:]]|[0-9]`)
//    var re = regexp.MustCompile(`[[:punct:]]`)

    //check each words in strSlice against censored slice
    for position, word := range strSlice {
        for _, forbiddenWord := range censWordsSlice {
            //if test := strings.Index(strings.ToLower(word), forbiddenWord); test > -1 {
            if strings.EqualFold(re.ReplaceAllString(strings.ToLower(word), ""), forbiddenWord) || strings.EqualFold(strings.ToLower(word), forbiddenWord) {
                // calculate how many # for replacement (for utf8 words value is wrong)
                replacement := strings.Repeat("#", len(word))
                strSlice[position] = replacement
                // run command
                actionEvent := json_data{
                    Type:       "cmd",
                    Message:    *CensMsgCommand,
                    Player:     player,
                    Command:    *CensRunCommand,
                    Args:       strings.Fields(player),
                }
                minetestResp <- actionEvent
            }
            newSlice = append(strSlice[:position], strSlice[position:]...)
        }
    }
    // convert []string slice back to string
    return strings.Join(newSlice, " ")
}
