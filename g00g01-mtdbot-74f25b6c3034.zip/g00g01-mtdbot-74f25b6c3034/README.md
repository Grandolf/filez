# mtdBot #

Version: 0.2.0

DiscordBot for Minetest.

# License of source code: AGPL v.3
Copyright (C) 2017 Litvinoff Pavel <googolgl@gmail.com>

# Notice:
Reprints messages from the general chat Minetest to Discord and back.
Support command in the Discord:

***!status*** - Server’s Minetest version, time the server is running in seconds list of connected players and the message of the day.

***!msg <player> <message>*** - Send a private message <message> to <player>.

***!ban <player name>*** - Ban IP of player.

***!unban <player name/IP address>*** - Remove ban of player with the specified name or IP address.

***!kick <player name> <reason>*** - Kicks the player with the name <player name>. Optionally a <reason> can be provided in text-form. This text is also shown to the kicked player.

***!setpassword <player> <password>*** - Sets password of <player> to <password>.

***!grant <player> <privilege>*** - Gives the <privilege> to <player>.

***!revoke <player> <privilege>*** - Takes away a <privilege> from <player>.

***!privs <player>*** - Show privs of player.

You can disable this by setting "SUPPORT_CMD = false" in "~/mods/http_api/subscriber/init.lua"

# Installing
Download the latest released version and build it:
```
hg clone https://g00g01@bitbucket.org/g00g01/mtdbot
cd mtdbot
go get github.com/bwmarrin/discordgo
go get github.com/jcuga/golongpoll
go build -o mtdBot
```
Install "http_api" minetest modpack.

```
1. Copy ~/mtdBot/minetest/mods/http_api > ~/minetest/mods/http_api
2. Add this mods to trusted_mods.
--- Open : /minetest/minetest.confg
--- Add : secure.http_mods = subscriber,publisher
3. Activate http_api mod in menu
```

# Usage
Add your bot.
```
Open https://discordapp.com/developers/applications/me
--- Click "New App"
--- Add "App Name" (Example: minetest-bot)
--- Push "Create App"
--- Push "Create a Bot User"
--- "Token:click to reveal", this is your TokenBot
--- Push "Save changes"
```
Edit config.ini

Run on the server:
```
mtdBot
```

# Links:
Bitbucket:
- <https://bitbucket.org/g00g01/mtdbot>

Discord:
- https://discordapp.com/
