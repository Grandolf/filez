Licenses: code LGPL 2.1 media CC BY-SA 3.0
Created by: UjEdwin
Date: 2016-03-28

This tool let you change metadata in node / blocks witha simple tool
Requires server priv
ownerhack:tool or hacktool