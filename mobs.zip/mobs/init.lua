-- Mob Api

dofile(minetest.get_modpath("mobs").."/api.lua")
