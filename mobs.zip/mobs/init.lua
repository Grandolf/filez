local path = minetest.get_modpath("mobs")

-- Mob Api
dofile(path.."/api.lua")

-- Animals
dofile(path.."/rat.lua") -- PilzAdam
dofile(path.."/bee.lua") -- KrupnoPavel
dofile(path.."/bunny.lua") -- ExeterDad
dofile(path.."/kitten.lua") -- Jordach/BFD

print ("[MOD] Mobs Redo loaded")
