PvP-Button Mod by Phiwari123
============================

This mod adds a PvP-Button to the player's inventory, which allows each
player on a server whether he/she wants to be attackable by others or not.

Current Version: 1.3

Dependencies: Either one of unified_inventory (recommended) or inventory_plus needs to be installed in order to use this mod

Report bugs or request help on the forum topic!


Installation
------------

Unzip the archive and place the folder in minetest/mods

For further information or help see:
http://wiki.minetest.net/Installing_Mods


License for Code
----------------

Copyright (C) 2015 Phiwari123 phiwari123@web.de

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. �See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

License for Textures, Models and Sounds
---------------------------------------

CC-BY-SA 3.0 UNPORTED. Created by Phiwari123

