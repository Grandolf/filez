local materials = {
    "brick"        ,
    "cobble"       ,
    "desert_stone" ,
    "glass"        ,
    "jungletree"   ,
    "mossycobble"  ,
    "pinetree"     ,
    "pinewood"     ,
    "sandstone"    ,
    "steelblock"   ,
    "stone"        ,
    "tree"         ,
    "wood"         ,
}

for _,material in ipairs (materials) do
    minetest.register_alias ("stairsplus:slab_" .. material,
        "stairs:slab_" .. material)
end
