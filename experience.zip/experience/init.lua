dofile(MP.."/config.lua")
level1 = 1
level1w_drop = 1w
level1f_drop = 1f
level1a_drop = 1a
level1t_drop = 1t

level2 = 2
level2w_drop = 2w
level2f_drop = 2f
level2t_drop = 2t
level2a_drop = 2a

level3 = 3
level3w_drop = 3w
level3f_drop = 3f
level3t_drop = 3t
level3a_drop = 3a

level4 = 4
level4w_drop = 4w
level4f_drop = 4f
level4t_drop = 4t
level4a_drop = 4a

level5 = 5
level5w_drop = 5w
level5f_drop = 5f
level5t_drop = 5t
level5a_drop = 5a

level6 = 6
level6w_drop = 6w
level6f_drop = 6f
level6t_drop = 6t
level6a_drop = 6a

level7 = 7
level7w_drop = 7w
level7f_drop = 7f
level7t_drop = 7t
level7a_drop = 7a

level8 = 8
level8w_drop = 8w
level8f_drop = 8f
level8t_drop = 8t
level8a_drop = 8a

level9 = 9
level9w_drop = 9w
level9f_drop = 9f
level9t_drop = 9t
level9a_drop = 9a

level10 = 10
level10w_drop = 10w
level10f_drop = 10f
level10t_drop = 10t
level10a_drop = 10a

level11 = 11
level11w_drop = 11w
level11f_drop = 11f
level11a_drop = 11a
level11t_drop = 11t

level12 = 12
level12w_drop = 12w
level12f_drop = 12f
level12t_drop = 12t
level12a_drop = 12a

level13 = 13
level13w_drop = 13w
level13f_drop = 13f
level13t_drop = 13t
level13a_drop = 13a

level14 = 14
level14w_drop = 14w
level14f_drop = 14f
level14t_drop = 14t
level14a_drop = 14a

level15 = 15
level15w_drop = 15w
level15f_drop = 15f
level15t_drop = 15t
level15a_drop = 15a

level16 = 16
level16w_drop = 16w
level16f_drop = 16f
level16t_drop = 16t
level16a_drop = 16a

level17 = 17
level17w_drop = 17w
level17f_drop = 17f
level17t_drop = 17t
level17a_drop = 17a

level18 = 18
level18w_drop = 18w
level18f_drop = 18f
level18t_drop = 18t
level18a_drop = 18a

level19 = 19
level19w_drop = 19w
level19f_drop = 19f
level19t_drop = 19t
level19a_drop = 19a

level20 = 20
level20w_drop = 20w
level20f_drop = 20f
level20t_drop = 20t
level20a_drop = 20a


--add an experience orb if player digs node from xp group
minetest.register_on_dignode(function(pos, oldnode, digger)
	namer = oldnode.name
	see_if_mineral = minetest.get_item_group(namer, "xp")
	if see_if_mineral > 0 then
		minetest.env:add_entity(pos, "experience:orb")
	end
end)
--give a new player some xp
minetest.register_on_newplayer(function(player)
	file = io.open(minetest.get_worldpath().."/"..player:get_player_name().."_experience", "w")
	file:write("0")
	file:close()
end)
--set player's xp level to 0 if they die
--minetest.register_on_dieplayer(function(player)
--	file = io.open(minetest.get_worldpath().."/"..player:get_player_name().."_experience", "w")
--	file:write("0")
--	file:close()
--end)

--Allow people to collect orbs
minetest.register_globalstep(function(dtime,player_name)
	for _,player in ipairs(minetest.get_connected_players()) do
		local pos = player:getpos()
		pos.y = pos.y+0.5
		for _,object in ipairs(minetest.env:get_objects_inside_radius(pos, 1)) do
			if not object:is_player() and object:get_luaentity() and object:get_luaentity().name == "experience:orb" then
				--RIGHT HERE ADD IN THE CODE TO UPGRADE PLAYERS 
				object:setvelocity({x=0,y=0,z=0})
				object:get_luaentity().name = "STOP"
				minetest.sound_play("orb", {
					to_player = player:get_player_name(),
				})
				xp = io.open(minetest.get_worldpath().."/"..player:get_player_name().."_experience", "r")
				experience = xp:read ("*l")

				if xp == nil then
                    xp = io.open (minetest.get_worldpath().."/"..player:get_player_name().."_experience", "w")
                    xp:write("1")
                    xp:close()

                    xp = io.open (minetest.get_worldpath().."/"..player:get_player_name().."_experience", "r")
                    if xp ~= nil then
    				    experience = xp:read ("*l")
	    			    xp:close()
                    end
				end

				if experience ~= nil then
					new_xp = experience + 1
					xp_write = io.open(minetest.get_worldpath().."/"..player:get_player_name().."_experience", "w")
					xp_write:write(new_xp)
					xp_write:close()

					if new_xp == level1 then
					if minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) then
						minetest.env:add_item(pos, level1w_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
						minetest.env:add_item(pos, level1f_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					if not minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
					if minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) then
						minetest.env:add_item(pos, level1t_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) then
						minetest.env:add_item(pos, level1a_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					if not minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) 
					then
					minetest.get_modpath("lottclasses")
					local path = minetest.get_modpath("lottclasses")
					dofile(path .. "/init.lua")
					minetest.show_formspec(name, "race_selector", race_chooser)
						end
					end
				end
			end

					if new_xp == level2 then
					if minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) then
						minetest.env:add_item(pos, level2w_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
						minetest.env:add_item(pos, level2f_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					if not minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
					if minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) then
						minetest.env:add_item(pos, level2t_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) then
						minetest.env:add_item(pos, level2a_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					if not minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) 
					then
					minetest.get_modpath("lottclasses")
					local path = minetest.get_modpath("lottclasses")
					dofile(path .. "/init.lua")
					minetest.show_formspec(name, "race_selector", race_chooser)
						end
					end
				end
			end

					if new_xp == level3 then
					if minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) then
						minetest.env:add_item(pos, level3w_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
						minetest.env:add_item(pos, level3f_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					if not minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
					if minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) then
						minetest.env:add_item(pos, level3t_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) then
						minetest.env:add_item(pos, level3a_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					if not minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) 
					then
					minetest.get_modpath("lottclasses")
					local path = minetest.get_modpath("lottclasses")
					dofile(path .. "/init.lua")
					minetest.show_formspec(name, "race_selector", race_chooser)
						end
					end
				end
			end
	
					if new_xp == level4 then
					if minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) then
						minetest.env:add_item(pos, level4w_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
						minetest.env:add_item(pos, level4f_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					if not minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
					if minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) then
						minetest.env:add_item(pos, level4t_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) then
						minetest.env:add_item(pos, level4a_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					if not minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) 
					then
					minetest.get_modpath("lottclasses")
					local path = minetest.get_modpath("lottclasses")
					dofile(path .. "/init.lua")
					minetest.show_formspec(name, "race_selector", race_chooser)
						end
					end
				end
			end	
					
					if new_xp == level5 then
					if minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) then
						minetest.env:add_item(pos, level5w_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
						minetest.env:add_item(pos, level5f_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					if not minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
					if minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) then
						minetest.env:add_item(pos, level5t_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) then
						minetest.env:add_item(pos, level5a_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					if not minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) 
					then
					minetest.get_modpath("lottclasses")
					local path = minetest.get_modpath("lottclasses")
					dofile(path .. "/init.lua")
					minetest.show_formspec(name, "race_selector", race_chooser)
						end
					end
				end
			end	
										
					if new_xp == level6 then
					if minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) then
						minetest.env:add_item(pos, level6w_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
						minetest.env:add_item(pos, level6f_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					if not minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
					if minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) then
						minetest.env:add_item(pos, level6t_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) then
						minetest.env:add_item(pos, level6a_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					if not minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) 
					then
					minetest.get_modpath("lottclasses")
					local path = minetest.get_modpath("lottclasses")
					dofile(path .. "/init.lua")
					minetest.show_formspec(name, "race_selector", race_chooser)
						end
					end
				end
			end
										
					if new_xp == level7 then
					if minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) then
						minetest.env:add_item(pos, level7w_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
						minetest.env:add_item(pos, level7f_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					if not minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
					if minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) then
						minetest.env:add_item(pos, level7t_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) then
						minetest.env:add_item(pos, level7a_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					if not minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) 
					then
					minetest.get_modpath("lottclasses")
					local path = minetest.get_modpath("lottclasses")
					dofile(path .. "/init.lua")
					minetest.show_formspec(name, "race_selector", race_chooser)
						end
					end
				end
			end
										
					if new_xp == level8 then
					if minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) then
						minetest.env:add_item(pos, level8w_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
						minetest.env:add_item(pos, level8f_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					if not minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
					if minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) then
						minetest.env:add_item(pos, level8t_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) then
						minetest.env:add_item(pos, level8a_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					if not minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) 
					then
					minetest.get_modpath("lottclasses")
					local path = minetest.get_modpath("lottclasses")
					dofile(path .. "/init.lua")
					minetest.show_formspec(name, "race_selector", race_chooser)
						end
					end
				end
			end
								
					if new_xp == level9 then
					if minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) then
						minetest.env:add_item(pos, level9w_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
						minetest.env:add_item(pos, level9f_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					if not minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
					if minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) then
						minetest.env:add_item(pos, level9t_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) then
						minetest.env:add_item(pos, level9a_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					if not minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) 
					then
					minetest.get_modpath("lottclasses")
					local path = minetest.get_modpath("lottclasses")
					dofile(path .. "/init.lua")
					minetest.show_formspec(name, "race_selector", race_chooser)
						end
					end
				end
			end	
										
					if new_xp == level10 then
					if minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) then
						minetest.env:add_item(pos, level10w_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
						minetest.env:add_item(pos, level10f_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					if not minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
					if minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) then
						minetest.env:add_item(pos, level10t_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) then
						minetest.env:add_item(pos, level10a_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					if not minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) 
					then
					minetest.get_modpath("lottclasses")
					local path = minetest.get_modpath("lottclasses")
					dofile(path .. "/init.lua")
					minetest.show_formspec(name, "race_selector", race_chooser)
						end
					end
				end
			end
					if new_xp == level11 then
					if minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) then
						minetest.env:add_item(pos, level11w_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
						minetest.env:add_item(pos, level11f_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					if not minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
					if minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) then
						minetest.env:add_item(pos, level11t_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) then
						minetest.env:add_item(pos, level11a_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					if not minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) 
					then
					minetest.get_modpath("lottclasses")
					local path = minetest.get_modpath("lottclasses")
					dofile(path .. "/init.lua")
					minetest.show_formspec(name, "race_selector", race_chooser)
						end
					end
				end
			end
					if new_xp == level12 then
					if minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) then
						minetest.env:add_item(pos, level12w_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
						minetest.env:add_item(pos, level12f_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					if not minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
					if minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) then
						minetest.env:add_item(pos, level12t_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) then
						minetest.env:add_item(pos, level12a_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					if not minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) 
					then
					minetest.get_modpath("lottclasses")
					local path = minetest.get_modpath("lottclasses")
					dofile(path .. "/init.lua")
					minetest.show_formspec(name, "race_selector", race_chooser)
						end
					end
				end
			end
					if new_xp == level13 then
					if minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) then
						minetest.env:add_item(pos, level13w_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
						minetest.env:add_item(pos, level13f_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					if not minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
					if minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) then
						minetest.env:add_item(pos, level13t_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) then
						minetest.env:add_item(pos, level13a_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					if not minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) 
					then
					minetest.get_modpath("lottclasses")
					local path = minetest.get_modpath("lottclasses")
					dofile(path .. "/init.lua")
					minetest.show_formspec(name, "race_selector", race_chooser)
						end
					end
				end
			end
					if new_xp == level14 then
					if minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) then
						minetest.env:add_item(pos, level14w_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
						minetest.env:add_item(pos, level14f_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					if not minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
					if minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) then
						minetest.env:add_item(pos, level14t_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) then
						minetest.env:add_item(pos, level14a_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					if not minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) 
					then
					minetest.get_modpath("lottclasses")
					local path = minetest.get_modpath("lottclasses")
					dofile(path .. "/init.lua")
					minetest.show_formspec(name, "race_selector", race_chooser)
						end
					end
				end
			end
					if new_xp == level9 then
					if minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) then
						minetest.env:add_item(pos, level14w_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
						minetest.env:add_item(pos, level14f_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					if not minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
					if minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) then
						minetest.env:add_item(pos, level14t_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) then
						minetest.env:add_item(pos, level14a_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					if not minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) 
					then
					minetest.get_modpath("lottclasses")
					local path = minetest.get_modpath("lottclasses")
					dofile(path .. "/init.lua")
					minetest.show_formspec(name, "race_selector", race_chooser)
						end
					end
				end
			end
					if new_xp == level15 then
					if minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) then
						minetest.env:add_item(pos, level15w_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
						minetest.env:add_item(pos, level15f_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					if not minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
					if minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) then
						minetest.env:add_item(pos, level15t_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) then
						minetest.env:add_item(pos, level15a_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					if not minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) 
					then
					minetest.get_modpath("lottclasses")
					local path = minetest.get_modpath("lottclasses")
					dofile(path .. "/init.lua")
					minetest.show_formspec(name, "race_selector", race_chooser)
						end
					end
				end
			end
					if new_xp == level16 then
					if minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) then
						minetest.env:add_item(pos, level17w_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
						minetest.env:add_item(pos, level17f_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					if not minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
					if minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) then
						minetest.env:add_item(pos, level17t_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) then
						minetest.env:add_item(pos, level17a_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					if not minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) 
					then
					minetest.get_modpath("lottclasses")
					local path = minetest.get_modpath("lottclasses")
					dofile(path .. "/init.lua")
					minetest.show_formspec(name, "race_selector", race_chooser)
						end
					end
				end
			end
					if new_xp == level18 then
					if minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) then
						minetest.env:add_item(pos, level18w_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
						minetest.env:add_item(pos, level18f_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					if not minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
					if minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) then
						minetest.env:add_item(pos, level18t_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) then
						minetest.env:add_item(pos, level18a_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					if not minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) 
					then
					minetest.get_modpath("lottclasses")
					local path = minetest.get_modpath("lottclasses")
					dofile(path .. "/init.lua")
					minetest.show_formspec(name, "race_selector", race_chooser)
						end
					end
				end
			end
					if new_xp == level19 then
					if minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) then
						minetest.env:add_item(pos, level19w_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
						minetest.env:add_item(pos, level19f_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					if not minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
					if minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) then
						minetest.env:add_item(pos, level19t_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) then
						minetest.env:add_item(pos, level19a_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					if not minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) 
					then
					minetest.get_modpath("lottclasses")
					local path = minetest.get_modpath("lottclasses")
					dofile(path .. "/init.lua")
					minetest.show_formspec(name, "race_selector", race_chooser)
						end
					end
				end
			end
					if new_xp == level20 then
					if minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) then
						minetest.env:add_item(pos, level20w_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
						minetest.env:add_item(pos, level20f_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					if not minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) then
					if minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) then
						minetest.env:add_item(pos, level20t_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					end
					else if minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) then
						minetest.env:add_item(pos, level20a_drop)
						minetest.sound_play("level_up", {
							to_player = player:get_player_name(),
						})
					if not minetest.check_player_privs(player:get_player_name(),{GAMEarcher=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEthief=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEwizard=true}) 
					or minetest.check_player_privs(player:get_player_name(),{GAMEfighter=true}) 
					then
					minetest.get_modpath("lottclasses")
					local path = minetest.get_modpath("lottclasses")
					dofile(path .. "/init.lua")
					minetest.show_formspec(name, "race_selector", race_chooser)
						end
					end
				end
			end	
				end
				object:remove()
			end
		end
		for _,object in ipairs(minetest.env:get_objects_inside_radius(pos, 3)) do
			if not object:is_player() and object:get_luaentity() and object:get_luaentity().name == "experience:orb" then
				if object:get_luaentity().collect then
					local pos1 = pos
					pos1.y = pos1.y+0.2
					local pos2 = object:getpos()
					local vec = {x=pos1.x-pos2.x, y=pos1.y-pos2.y, z=pos1.z-pos2.z}
					vec.x = vec.x*3
					vec.y = vec.y*3
					vec.z = vec.z*3
					object:setvelocity(vec)
				end
			end
		end
	end
end)

minetest.register_entity("experience:orb", {
	physical = true,
	timer = 0,
	textures = {"orb.png"},
	visual_size = {x=0.3, y=0.3},
	collisionbox = {-0.17,-0.17,-0.17,0.17,0.17,0.17},
	on_activate = function(self, staticdata)
		self.object:set_armor_groups({immortal=1})
		self.object:setvelocity({x=0, y=1, z=0})
		self.object:setacceleration({x=0, y=-10, z=0})
	end,
	collect = true,
	on_step = function(self, dtime)
		self.timer = self.timer + dtime
		if (self.timer > 300) then
			self.object:remove()
		end
		local p = self.object:getpos()
		local nn = minetest.env:get_node(p).name
		noder = minetest.env:get_node(p).name
		p.y = p.y - 0.3
		local nn = minetest.env:get_node(p).name
		if not minetest.registered_nodes[nn] or minetest.registered_nodes[nn].walkable then
			if self.physical_state then
				self.object:setvelocity({x=0, y=0, z=0})
				self.object:setacceleration({x=0, y=0, z=0})
				self.physical_state = false
				self.object:set_properties({
					physical = false
				})
			end
		else
			if not self.physical_state then
				self.object:setvelocity({x=0,y=0,z=0})
				self.object:setacceleration({x=0, y=-10, z=0})
				self.physical_state = true
				self.object:set_properties({
					physical = true
				})
			end
		end
	end,
})
