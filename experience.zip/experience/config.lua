level1 = 1
level1w_drop = "classes:staff_wood"
level1f_drop = "classes:staff_wood"
level1a_drop = "classes:staff_wood"
level1t_drop = "classes:staff_wood"

level2 = 10
level2w_drop = "classes:apprentice_staff"
level2f_drop = ""
level2t_drop = ""
level2a_drop = ""

level3 = 50
level3w_drop = ""
level3f_drop = ""
level3t_drop = ""
level3a_drop = ""

level4 = 100
level4w_drop = ""
level4f_drop = ""
level4t_drop = ""
level4a_drop = ""

level5 = 500
level5w_drop = "classes:lightning"
level5f_drop = ""
level5t_drop = ""
level5a_drop = ""

level6 = 1000
level6w_drop = ""
level6f_drop = ""
level6t_drop = ""
level6a_drop = ""

level7 = 1500
level7w_drop = ""
level7f_drop = ""
level7t_drop = ""
level7a_drop = ""

level8 = 2000
level8w_drop = ""
level8f_drop = ""
level8t_drop = ""
level8a_drop = ""

level9 = 2500
level9w_drop = ""
level9f_drop = ""
level9t_drop = ""
level9a_drop = ""

level10 = 5000
level10w_drop = "classes:firestaff"
level10f_drop = ""
level10t_drop = ""
level10a_drop = ""

level11 = 10000
level11w_drop = "classes:apprentice"
level11f_drop = ""
level11a_drop = ""
level11t_drop = ""

level12 = 15000
level12w_drop = ""
level12f_drop = ""
level12t_drop = ""
level12a_drop = ""

level13 = 20000
level13w_drop = ""
level13f_drop = ""
level13t_drop = ""
level13a_drop = ""

level14 = 30000
level14w_drop = ""
level14f_drop = ""
level14t_drop = ""
level14a_drop = ""

level15 = 40000
level15w_drop = ""
level15f_drop = ""
level15t_drop = ""
level15a_drop = ""

level16 = 50000
level16w_drop = ""
level16f_drop = ""
level16t_drop = ""
level16a_drop = ""

level17 = 100000
level17w_drop = ""
level17f_drop = ""
level17t_drop = ""
level17a_drop = ""

level18 = 250000
level18w_drop = ""
level18f_drop = ""
level18t_drop = ""
level18a_drop = ""

level19 = 500000
level19w_drop = ""
level19f_drop = ""
level19t_drop = ""
level19a_drop = ""

level20 = 1000000
level20w_drop = ""
level20f_drop = ""
level20t_drop = ""
level20a_drop = ""
