This modpack began life as the Castles Mod by Philipbenr And DanDuncombe.

It contains a variety of items useful for building castles and castle dungeons.