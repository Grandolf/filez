=-=-=-=-=-=-=-=-=-=

Castles Mod
by: Philipbenr And DanDuncombe

=-=-=-=-=-=-=-=-=-=

Licence: MIT, LGPLv2.1 (Crossbow)

see: LICENSE

=-=-=-=-=-=-=-=-=-=

This is a mod all about creating castles and castle dungeons. Many of the nodes are used for the outer-walls or dungeons.

=-=-=-=-=-=-=-=-=-=

Contains as of now:

--Walls, Corner-walls,
--Castlestone Stairs, Slabs, and Pillars
--Jailbars
--Hides
--Arrows and Arrowslits
--Rubble
--Doors
--Weapons
--Chandeliers
--Tapestries
--and more!

=-=-=-=-=-=-=-=-=-=

Big release coming soon.  ;)  Stay tuned.

Planned features (anything with question mark means that I am either unsure or don't know how to accomplish it ;)

--More/Better weapons
--More decorations
--More nodes
--Redone columns
--More doors
--Gatehouse mod
--Armor
--More magical items (mana, orbs, potions...)
--Crowns/capes/player decor
--Flags
--Brewery/Liquor (liquor effects is another thing altogether)
--Tannery?
--Dye Vats?
--Books? (that is an interesting one... I'll write a post on it later)
--Guards?
--Player status (King, queen, etc.)?
--Foods?
--Horses/Livestock?
--Ruins?

--Modpack Configurator 
