--immagration center

--VARIABLES
  local bees = {}
  local formspecs = {}

--FUNCTIONS

  function formspecs.immigration_center(pos)
    local spos = pos.x..','..pos.y..','..pos.z
    local formspec =
      'size[8,9]'..
      'list[nodemeta:'..spos..';sign;3.5,1;1,1;]'..
      'list[nodemeta:'..spos..';beds;0,3;8,1;]'..
      'list[current_player;main;0,5;8,4;]'
    return formspec
end
 function formspecs.mine_stone(pos)
    local spos = pos.x..','..pos.y..','..pos.z
    local formspec =
      'size[8,9]'..
      'list[nodemeta:'..spos..';miner;3.5,1;1,1;]'..
      'list[nodemeta:'..spos..';pick;0,3;8,1;]'..
      'list[current_player;main;0,5;8,4;]'
    return formspec
  end
  minetest.register_node('nodes:immigration_center', {
    description = 'immigration center',
    tiles = {'default_wood.png','default_wood.png','default_wood.png', 'default_wood.png','default_wood.png','default_wood.png'},
    drawtype = 'nodebox',
    paramtype = 'light',
    paramtype2 = 'facedir',
    groups = {snappy=1,choppy=2,oddly_breakable_by_hand=2,flammable=3,wood=1},
    sounds = default.node_sound_wood_defaults(),
    node_box = {
      type = 'fixed',
      fixed = {
        {-4/8, 2/8, -4/8, 4/8, 3/8, 4/8},
        {-3/8, -4/8, -2/8, 3/8, 2/8, 3/8},
        {-3/8, 0/8, -3/8, 3/8, 2/8, -2/8},
        {-3/8, -4/8, -3/8, 3/8, -1/8, -2/8},
        {-3/8, -1/8, -3/8, -1/8, 0/8, -2/8},
        {1/8, -1/8, -3/8, 3/8, 0/8, -2/8},
      }
    },
    on_construct = function(pos)
      local timer = minetest.get_node_timer(pos)
      local meta = minetest.get_meta(pos)
      local inv = meta:get_inventory()
      meta:set_int('agressive', 0)
      inv:set_size('sign', 1)
      inv:set_size('beds', 8)
      meta:set_string('infotext','requires sign to function')
    end,
    on_rightclick = function(pos, node, clicker, itemstack)
      minetest.show_formspec(
        clicker:get_player_name(),
        'nodes:immigration_center',
        formspecs.immigration_center(pos)
      )
      local meta = minetest.get_meta(pos)
      local inv  = meta:get_inventory()
      if meta:get_int('agressive') == 1 and inv:contains_item('sign', 'default:sign_wall_wood') then
        local health = clicker:get_hp()
        clicker:set_hp(health)
      else
        meta:set_int('agressive', 0)
      end
    end,
    on_timer = function(pos,elapsed)
      local meta = minetest.get_meta(pos)
      local inv = meta:get_inventory()
      local timer = minetest.get_node_timer(pos)
      if inv:contains_item('sign', 'default:sign_wall_wood') then
        if inv:contains_item('beds', 'beds:bed_bottom') then
          timer:start(30)
          local rad  = 10
          local minp = {x=pos.x-rad, y=pos.y-rad, z=pos.z-rad}
          local maxp = {x=pos.x+rad, y=pos.y+rad, z=pos.z+rad}
          local progress = meta:get_int('progress')
          progress = progress + 1
          meta:set_int('progress', progress)
          if progress > 1000 then
            local stacks = inv:get_list('beds')
            for k, v in pairs(stacks) do
              if inv:get_stack('beds', k):get_name() == 'beds:bed_bottom' then
                meta:set_int('progress', 0)
                inv:set_stack('beds',k,'nodes:citizen')
                return
              end
            end
          else
            meta:set_string('infotext', 'progress: '..progress..'/1000')
          end
        else
          meta:set_string('infotext', 'does not have empty bed(s)')
          timer:stop()
        end
      end
    end,
    on_metadata_inventory_take = function(pos, listname, index, stack, player)
      if listname == 'sign' then
        local timer = minetest.get_node_timer(pos)
        local meta = minetest.get_meta(pos)
        meta:set_string('infotext','requires sign to function')
        timer:stop()
      end
    end,
    allow_metadata_inventory_move = function(pos, from_list, from_index, to_list, to_index, count, player)
      local inv = minetest.get_meta(pos):get_inventory()
      if from_list == to_list then 
        if inv:get_stack(to_list, to_index):is_empty() then
          return 1
        else
          return 0
        end
      else
        return 0
      end
    end,
    on_metadata_inventory_put = function(pos, listname, index, stack, player)
      local meta = minetest.get_meta(pos)
      local inv = meta:get_inventory()
      local timer = minetest.get_node_timer(pos)
      if listname == 'sign' or listname == 'beds' then
        meta:set_string('sign', stack:get_name())
        meta:set_string('infotext','sign is inserted, now for the beds');
        if inv:contains_item('beds', 'beds:bed_bottom') then
          timer:start(30)
          meta:set_string('infotext','people are discovering your kingdom');
        end
      end
    end,
    allow_metadata_inventory_put = function(pos, listname, index, stack, player)
      if not minetest.get_meta(pos):get_inventory():get_stack(listname, index):is_empty() then return 0 end
      if listname == 'sign' then
        if stack:get_name():match('default:sign_wall_wood*') then
          return 1
        end
      elseif listname == 'beds' then
        if stack:get_name() == ('beds:bed_bottom') then
          return 1
        end
      end
      return 0
    end,
  })

 minetest.register_node('nodes:mine_stone', {
    description = 'stone mine',
    tiles = {'default_wood.png','default_wood.png','default_wood.png', 'default_wood.png','default_wood.png','bees_hive_artificial.png'},
    drawtype = 'nodebox',
    paramtype = 'light',
    paramtype2 = 'facedir',
    groups = {snappy=1,choppy=2,oddly_breakable_by_hand=2,flammable=3,wood=1},
    sounds = default.node_sound_wood_defaults(),
    node_box = {
      type = 'fixed',
      fixed = {
        {-4/8, 2/8, -4/8, 4/8, 3/8, 4/8},
        {-3/8, -4/8, -2/8, 3/8, 2/8, 3/8},
        {-3/8, 0/8, -3/8, 3/8, 2/8, -2/8},
        {-3/8, -4/8, -3/8, 3/8, -1/8, -2/8},
        {-3/8, -1/8, -3/8, -1/8, 0/8, -2/8},
        {1/8, -1/8, -3/8, 3/8, 0/8, -2/8},
      }
    },
    on_construct = function(pos)
      local timer = minetest.get_node_timer(pos)
      local meta = minetest.get_meta(pos)
      local inv = meta:get_inventory()
      meta:set_int('agressive', 1)
      inv:set_size('miner', 1)
      inv:set_size('pick', 8)
      meta:set_string('infotext','requires miner to function')
    end,
    on_rightclick = function(pos, node, clicker, itemstack)
      minetest.show_formspec(
        clicker:get_player_name(),
        'nodes:miner_stone',
        formspecs.mine_stone(pos)
      )
      local meta = minetest.get_meta(pos)
      local inv  = meta:get_inventory()
      if meta:get_int('agressive') == 1 and inv:contains_item('miner', 'nodes:miner_stone') then
        local health = clicker:get_hp()
        clicker:set_hp(health)
      else
        meta:set_int('agressive', 1)
      end
    end,
    on_timer = function(pos,elapsed)
      local meta = minetest.get_meta(pos)
      local inv = meta:get_inventory()
      local timer = minetest.get_node_timer(pos)
      if inv:contains_item('miner', 'nodes:miner_stone') then
        if inv:contains_item('pick', 'default:pick_stone') then
          timer:start(30)
          local rad  = 10
          local minp = {x=pos.x-rad, y=pos.y-rad, z=pos.z-rad}
          local maxp = {x=pos.x+rad, y=pos.y+rad, z=pos.z+rad}
          local flower = minetest.find_nodes_in_area(minp, maxp, 'group:flower')
          local progress = meta:get_int('progress')
          progress = progress + #flower
          meta:set_int('progress', progress)
          if progress > 1000 then
            local flower = flower[math.random(#flower)] 
            bees.polinate_flower(flower, minetest.get_node(flower).name)
            local stacks = inv:get_list('frames')
            for k, v in pairs(stacks) do
              if inv:get_stack('pick', k):get_name() == 'default:pick_stone' then
                meta:set_int('progress', 0)
                inv:set_stack('pick',k,'default:pick_stone')
                return
              end
            end
          else
            meta:set_string('infotext', 'progress: '..progress..'+'..#flowers..'/1000')
          end
        else
          meta:set_string('infotext', 'does not have picks for the miner to mine with')
          timer:stop()
        end
      end
    end,
    on_metadata_inventory_take = function(pos, listname, index, stack, player)
      if listname == 'miner' then
        local timer = minetest.get_node_timer(pos)
        local meta = minetest.get_meta(pos)
        meta:set_string('infotext','requires miner to function')
        timer:stop()
      end
    end,
    allow_metadata_inventory_move = function(pos, from_list, from_index, to_list, to_index, count, player)
      local inv = minetest.get_meta(pos):get_inventory()
      if from_list == to_list then 
        if inv:get_stack(to_list, to_index):is_empty() then
          return 1
        else
          return 0
        end
      else
        return 0
      end
    end,
    on_metadata_inventory_put = function(pos, listname, index, stack, player)
      local meta = minetest.get_meta(pos)
      local inv = meta:get_inventory()
      local timer = minetest.get_node_timer(pos)
      if listname == 'miner' or listname == 'pick' then
        meta:set_string('miner', stack:get_name())
        meta:set_string('infotext','miner is hired, now give him something to dig with');
        if inv:contains_item('pick', 'default:pick_stone') then
          timer:start(30)
          meta:set_string('infotext','miner is eating lunch');
        end
      end
    end,
    allow_metadata_inventory_put = function(pos, listname, index, stack, player)
      if not minetest.get_meta(pos):get_inventory():get_stack(listname, index):is_empty() then return 0 end
      if listname == 'miner' then
        if stack:get_name():match('nodes:miner_stone*') then
          return 1
        end
      elseif listname == 'picks' then
        if stack:get_name() == ('default:pick_stone') then
          return 1
        end
      end
      return 0
    end,
  })

  minetest.register_craftitem('nodes:citizen', {
    description = 'unemployed citizen',
    inventory_image = 'citizen.png',
    stack_max = 24,
  })
  minetest.register_craftitem('nodes:miner_stone', {
    description = 'stone miner',
    inventory_image = 'nodes_miner_stone.png',
    stack_max = 24,
  })
  minetest.register_craftitem('nodes:miner_iron', {
    description = 'iron miner',
    inventory_image = 'nodes_miner_iron.png',
    stack_max = 24,
  })
  minetest.register_craftitem('nodes:miner_copper', {
    description = 'copper miner',
    inventory_image = 'nodes_miner_copper.png',
    stack_max = 24,
  })
  minetest.register_craftitem('nodes:miner_mese', {
    description = 'mese miner',
    inventory_image = 'nodes_miner_mese.png',
    stack_max = 24,
  })
  minetest.register_craftitem('nodes:miner_diamond', {
    description = 'diamond miner',
    inventory_image = 'nodes_miner_diamond.png',
    stack_max = 24,
  })

