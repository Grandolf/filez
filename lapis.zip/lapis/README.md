===========================

#Minetest mod "Lapis"

modified by Napiophelios

Forum Topic :

https://forum.minetest.net/viewtopic.php?f=9&t=12368

![Preview](https://forum.minetest.net/download/file.php?mode=view&id=2780&sid=2afc22e146d22d7b15e6889ac4eeedff)

===========================

Lapis Lazuli mod requires

Minetest engine 0.4.13 development build 
(commit 1d69116 or later)
for the new sheet ore parameters.

and the development version of Minetest Game 0.4.14 
(commit fa9a345 or later)
for the new metal sound effects.

===========================

This mod adds several decorative nodes

based on Lapus Lazuli and Pyrite ore.

Players can mine Lapis and Pyrite ores;

craft stairs, slabs, columns, floor tiles, and bricks
from the ores' drops.

=================================

the original Minetest mod:

Lapis Lazuli mod v1.0

Written 2015 by LNJ

License of source code:
WTFPL

------------------------------------

code refinements by Xanthin

------------------------------------

--Nodeboxes for Columns designed

--by Artemis from Middle-Ages mod

--Licensed: WTFPL

--basecode is from Minetest Stairs mod

-Licensed under GPLv3 or later,

see http://www.gnu.org/licenses/gpl-3.0.html

===================================

Textures by Napiophelios
License: WTFPL

lapis_block.png

lapis_brick.png

lapis_brick_side.png

lapis_brick_top.png

lapis_cobble.png

lapis_lazurite_block.png

lapis_lazurite_brick.png

lapis_lazurite_brick_side.png

lapis_lazurite_brick_top.png

lapis_rosace_front.png

lapis_rosace_side.png

lapis_stone.png

lapis_tile.png


------------------------------------

Pyrite textures based on/derived from 

Gambit's (PixelBox) Pyrite textures

License: WTFPL

lapis_mineral_pyrite.png

lapis_pyrite_block.png

lapis_pyrite_ingot.png

lapis_pyrite_nugget.png

lapis_pyrite_sacred.png

===================================

WTFPL:
This program is free software. It comes without any warranty, to
the extent permitted by applicable law. You can redistribute it
and/or modify it under the terms of the Do What The Fuck You Want
To Public License, Version 2, as published by Sam Hocevar. See
http://sam.zoy.org/wtfpl/COPYING for more details.

===================================

            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
                    Version 2, December 2004

 Copyright (C) 2004 Sam Hocevar <sam@hocevar.net>

 Everyone is permitted to copy and distribute verbatim or modified
 copies of this license document, and changing it is allowed as long
 as the name is changed.

            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION

  0. You just DO WHAT THE FUCK YOU WANT TO.

===================================
