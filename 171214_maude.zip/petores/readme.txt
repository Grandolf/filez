License: CC BY-NC-ND 4.0 OldCoder
