dofile(minetest.get_modpath("petores").."/ores.lua")
